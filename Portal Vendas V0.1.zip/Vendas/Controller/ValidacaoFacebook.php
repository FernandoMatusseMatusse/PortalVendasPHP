<?php 
session_start();
//unset($_SESSION['face_access_token']);
require_once '../Boostrap4/lib/Facebook/autoload.php';
include_once './Conexao.php';
$fb = new \Facebook\Facebook([
  'app_id' => '{app-id}',
  'app_secret' => '{app-secret}',
  'default_graph_version' => 'v2.9',
  //'default_access_token' => '{access-token}', // optional
]);