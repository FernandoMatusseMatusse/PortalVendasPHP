<?php 
session_start();
include_once './Conexao.php';



$renda = filter_input(INPUT_POST, 'campoRenda', FILTER_SANITIZE_STRING);
$bairro= filter_input(INPUT_POST, 'campoBairro', FILTER_SANITIZE_STRING);
$tipo = filter_input(INPUT_POST, 'campoTipo', FILTER_SANITIZE_STRING);
$dimensao = filter_input(INPUT_POST, 'campoDimensao', FILTER_SANITIZE_STRING);
$detalhes = filter_input(INPUT_POST, 'campoDetalhes', FILTER_SANITIZE_STRING);
$preco = filter_input(INPUT_POST, 'campoPreco', FILTER_SANITIZE_STRING);
$email = filter_input(INPUT_POST, 'campoEmail', FILTER_SANITIZE_STRING);
$telefone = filter_input(INPUT_POST, 'campoTelefone', FILTER_SANITIZE_STRING);







//var_dump($_FILES['arquivo']);
$name=$_FILES['arquivo']['name'];
$temp=$_FILES['arquivo']['tmp_name'];

if(move_uploaded_file($temp, "./foto/".$name)){
  
  $sql_code="INSERT INTO casa(codigo,renda,bairro,tipo,dimensao,detalhes,preco,email,telefone,img,data)VALUES(null,'$renda','$bairro','$tipo','$dimensao','$detalhes','$preco','$email','$telefone','$name',NOW())";
$resultado=mysqli_query($conn, $sql_code);
    $sql_album="INSERT INTO album(codigo,campoum,campodois,campotres,campoquatro,campocinco,camposeis,camposete,campooito,img,data)VALUES(null,'$bairro','$renda','$tipo','$dimensao','$detalhes','$preco','$email','$telefone','$name',NOW())";
$resultado_album=mysqli_query($conn, $sql_album);


echo "		<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=http://localhost/Vendas/View/CompraTudo.php'>
					<script type=\"text/javascript\">
						alert(\"Venda Anuciada com sucesso!\");
					</script>
				";
}

  else {
     echo "
				<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=http://localhost/Vendas/View/VendaCasas.php'>
					<script type=\"text/javascript\">
						alert(\"Ocorreu algum  erro ao anuciar a venda!\");
					</script>
				";
  }
