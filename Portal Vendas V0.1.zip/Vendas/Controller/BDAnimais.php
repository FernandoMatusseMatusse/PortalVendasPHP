<?php 
session_start();
include_once './Conexao.php';



$nome = filter_input(INPUT_POST, 'campoNome', FILTER_SANITIZE_STRING);
$tamanho = filter_input(INPUT_POST, 'campoTamanho', FILTER_SANITIZE_STRING);
$idade = filter_input(INPUT_POST, 'campoIdade', FILTER_SANITIZE_STRING);
$temperamento = filter_input(INPUT_POST, 'campoTemperamento', FILTER_SANITIZE_STRING);
$sexo = filter_input(INPUT_POST, 'campoSexo', FILTER_SANITIZE_STRING);
$preco = filter_input(INPUT_POST, 'campoPreco', FILTER_SANITIZE_STRING);
$email = filter_input(INPUT_POST, 'campoEmail', FILTER_SANITIZE_STRING);
$telefone = filter_input(INPUT_POST, 'campoTelefone', FILTER_SANITIZE_STRING);


//var_dump($_FILES['arquivo']);
$name=$_FILES['arquivo']['name'];
$temp=$_FILES['arquivo']['tmp_name'];

if((move_uploaded_file($temp, "./foto/".$name))){

    $sql_code="INSERT INTO  animais (codigo,nome,tamanho,idade,temperamento,sexo,preco,email,telefone,img,data) VALUES (null, '$nome','$tamanho','$idade','$temperamento','$sexo','$preco','$email','$telefone','$name',NOW())";
$resultado=mysqli_query($conn, $sql_code);
    $sql_album="INSERT INTO album(codigo,campoum,campodois,campotres,campoquatro,campocinco,camposeis,camposete,campooito,img,data)VALUES(null, '$nome','$tamanho','$idade','$temperamento','$sexo','$preco','$email','$telefone','$name',NOW())";
$resultado_album=mysqli_query($conn, $sql_album);
echo "		<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=http://localhost/Vendas/View/CompraAnimais.php'>
					<script type=\"text/javascript\">
						alert(\"Venda Anunciada com sucesso!\");
					</script>
				";
}
  else {
     echo "
				<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=http://localhost/Vendas/View/VendaAnimais.php'>
					<script type=\"text/javascript\">
						alert(\"Ocorreu algum  erro ao anunciar a venda!\");
					</script>
				";
  }
