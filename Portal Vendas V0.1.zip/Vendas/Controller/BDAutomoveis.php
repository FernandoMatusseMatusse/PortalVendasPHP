<?php 
session_start();
include_once './Conexao.php';


$marca = filter_input(INPUT_POST, 'campoMarca', FILTER_SANITIZE_STRING);
$modelo= filter_input(INPUT_POST, 'campoModelo', FILTER_SANITIZE_STRING);
$quilometragem= filter_input(INPUT_POST, 'campoQuilometragem', FILTER_SANITIZE_STRING);
$detalhes = filter_input(INPUT_POST, 'campoDetalhes', FILTER_SANITIZE_STRING);
$ano = filter_input(INPUT_POST, 'campoAno', FILTER_SANITIZE_STRING);
$preco= filter_input(INPUT_POST, 'campoPreco', FILTER_SANITIZE_STRING);
$telefone = filter_input(INPUT_POST, 'campoTelefone', FILTER_SANITIZE_STRING);
$email = filter_input(INPUT_POST, 'campoEmail', FILTER_SANITIZE_STRING);



//var_dump($_FILES['arquivo']);
$name=$_FILES['arquivo']['name'];
$temp=$_FILES['arquivo']['tmp_name'];

if((move_uploaded_file($temp, "./foto/".$name))){
move_uploaded_file($temp, "./fotos/".$name);
    $sql_code="INSERT INTO  automoveis (codigo,marca,modelo,quilometragem,detalhes,ano,preco,telefone,email,img,data) VALUES (null, '$marca', '$modelo', '$quilometragem', '$detalhes', '$ano','$preco','$telefone','$email','$name',NOW())";
$resultado=mysqli_query($conn, $sql_code);
    $sql_album="INSERT INTO album(codigo,campoum,campodois,campotres,campoquatro,campocinco,camposeis,camposete,campooito,img,data)VALUES  (null, '$marca', '$modelo', '$quilometragem', '$detalhes', '$ano','$preco','$telefone','$email','$name',NOW())";
$resultado_album=mysqli_query($conn, $sql_album);

echo "		<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=http://localhost/Vendas/View/CompraTudo.php'>
					<script type=\"text/javascript\">
						alert(\"Venda Anuciada com sucesso!\");
					</script>
				";
}

  else {
     echo "
				<META HTTP-EQUIV=REFRESH CONTENT = '0;URL=http://localhost/Vendas/View/VendaAutomoveis.php'>
					<script type=\"text/javascript\">
						alert(\"Ocorreu algum  erro ao anuciar a venda!\");
					</script>
				";
  }
