<?php

/*
$utf8 =header("Content-Type: text/html; charset=utf-8");
$link = new mysqli('localhost','root','','pwt');
$link->set_charset('utf8');
*/

$servidor = "localhost";
$usuario ="root";
$senha ="";
$nomeBD="vendas";

// criação da conexão

$conn= mysqli_connect($servidor, $usuario, $senha, $nomeBD);
