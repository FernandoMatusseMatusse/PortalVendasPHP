
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.

@author Fernando Litos Cláudio Matusse
@contacto: +258846522986 / +258820308495
email: fernandomatussematusse@gmail.com
-->
<html  lang="PT-pt">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">

        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

      <title>Portaldevendas.com</title>

        <!-- Bootstrap core CSS -->
        <link href="../Boostrap4/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="../Boostrap4/css/style.css" />
        
               <!-- Custom styles for this template -->
        <link href="../Boostrap4/css/dashboard.css" rel="stylesheet">
        
        
        
    </head>
    <body>
        <!--Top Menu-->
        
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="true" aria-controls="navbar">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">Portal de Vendas</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
            <li><a >Hora</a></li>
              <li><a href="#">Nome</a></li>
            <li><a href="#">Sair</a></li>
          </ul>
          <form class="navbar-form navbar-right">
            <input type="text" class="form-control" placeholder="Busca...">
          </form>
        </div>
      </div>
    </nav>
        
        
        <!--Lateral Menu-->
            <div class="container-fluid">
      <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
    <ul id="nav" >

            <li><a href="#">Home</a></li>
            <li><a href="#">Sobre Nós</a></li>
            <li><a href="#">Novidades</a></li>
            <li><a href="#">Venda</a>

                <ul>
                    <li><a href="#">Animal</a></li>
                    <li><a href="#">Automoveis</a></li>
                    <li><a href="#">Casas/Terenos</a></li>
                    <li><a href="#">Electrodomesticos e Informatica</a></li>
                    <li><a href="#">Serviços</a></li>
                    <li><a href="#">Vestuários</a></li>
                </ul>

            </li>
            <li><a href="#">Compra</a>

                <ul>
                    <li><a href="#">Animal</a></li>
                    <li><a href="#">Automoveis</a></li>
                    <li><a href="#">Casas/Terenos</a></li>
                    <li><a href="#">Electrodomesticos e Informatica</a></li>
                    <li><a href="#">Serviços</a></li>
                    <li><a href="#">Vestuários</a></li>
                </ul>

            </li>
            
        </ul>
        </div>
          
                          <div>
                    <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
                        <div class="col-md-12">
                                   <div class="container theme-showcase" role="main">
                   <div class="page-header">
                <div class="col-md-2">
                    <img src="../Controller/Car_Icon.png"  width="100" height="100" style="margin-bottom: 25px;" >
                </div>
                <div class="col-md-7">
                <h1>Anunciar Automoveis</h1>
            </div>
            </div>
        <!--Formulario-->
        <form  method="post" action="../Controller/BDAutomoveis.php" enctype="multipart/form-data">
            <div  class="col-md-12"  style="align-self:   center">
                        <!--campo Marca do automovel-->
                <div class="col-md-5">
                    <div class="form-group">
                        <label for="campoMarca">Marca</label>
                        <select class="form-control" id="campoTipo" name="campoMarca">                                              
                                             <option value="1">Escolha uma Opção</option>
                                                <option value="alfa-romeo"
                                                        >Alfa Romeo</option>
                                           
                                                <option value="audi"
                                                        >Audi</option>
                                            
                                                <option value="bmw"
                                                        >BMW</option>
                                            
                                                <option value="cadillac"
                                                        >Cadillac</option>
                                                                                       
                                                <option value="chery"
                                                        >Chery</option>
                                            
                                                <option value="chevrolet"
                                                        >Chevrolet</option>
                                            
                                                <option value="chrysler"
                                                        >Chrysler</option>
                                               
                                                <option value="dodge"
                                                        >Dodge</option>

                                            
                                                <option value="fiat"
                                                        >Fiat</option>
                                            
                                                <option value="ford"
                                                        >Ford</option>

                                            
                                                <option value="hino"
                                                        >Hino</option>
                                            
                                                <option value="honda"
                                                        >Honda</option>
                                            
                                                <option value="hummer"
                                                        >Hummer</option>
                                            
                                                <option value="hyundai"
                                                        >Hyundai</option>

                                                <option value="isuzu"
                                                        >Isuzu</option>
                                            
                                                <option value="jac"
                                                        >JAC</option>
                                            
                                                <option value="jaguar"
                                                        >Jaguar</option>
                                            
                                                <option value="jeep"
                                                        >Jeep</option>
                                            
                                                <option value="kia"
                                                        >Kia</option>
                                            
                                                <option value="land-rover"
                                                        >Land Rover</option>
                                            
                                                <option value="lexus"
                                                        >Lexus</option>
                                            
                                                <option value="mini"
                                                        >MINI</option>
                                            
                                                <option value="mahindra"
                                                        >Mahindra</option>
                                            
                                                <option value="mazda"
                                                        >Mazda</option>
                                            
                                                <option value="mercedes-benz"
                                                        >Mercedes-Benz</option>
                                            
                                                <option value="mitsubishi"
                                                        >Mitsubishi</option>
                                            
                                                <option value="nissan"
                                                        >Nissan</option>
                                            
                                                <option value="opel"
                                                        >Opel</option>
                                            
                                                <option value="peugeot"
                                                        >Peugeot</option>
                                            
                                                <option value="pontiac"
                                                        >Pontiac</option>
                                            
                                                <option value="porsche"
                                                        >Porsche</option>
                                            
                                                <option value="renault"
                                                        >Renault</option>
                                            
                                                <option value="rover"
                                                        >Rover</option>
                                                                                       
                                                <option value="subaru"
                                                        >Subaru</option>
                                            
                                                <option value="suzuki"
                                                        >Suzuki</option>
                                            
                                                <option value="tesla"
                                                        >Tesla</option>
                                            
                                                <option value="toyota"
                                                        >Toyota</option>
                                            
                                                <option value="volkswagen"
                                                        >Volkswagen</option>
                                            
                                                <option value="volvo"
                                                        >Volvo</option>

                        </select>
                    </div>                                  
                </div>
   
          <!--campo Modelo-->
                <div class="col-md-5">
                    <div class="form-group">
                        <label for="campoModelo">Modelo</label>
                        <input type="text" class="form-control" id="campoModelo" name="campoModelo" placeholder="Digite o Modelo do Automovel" required>
                    </div>                                  
                </div>   
          
          <!--campo Quilometragem-->
                <div class="col-md-5">
                    <div class="form-group">
                        <label for="campoQuilometragem">Quilometragem</label>
                        <input type="number" class="form-control" id="campoQuilometragem" name="campoQuilometragem" placeholder="Digite a Quilometragem" required>
                    </div>                                  
                </div>   
          
          
                             <!--campo Quilometragem-->
                <div class="col-md-5">
                    <div class="form-group">
                        <label for="campoDetalhes">Detalhes</label>
                        <textarea class="form-control" id="campoDetalhes" name="campoDetalhes" placeholder="Detalhes" required ></textarea>
                    </div>                                  
                </div>    
                             
                             
                             
                <div class="col-md-5">
                    <div class="form-group">
                        <label for="campoAno">Ano</label>
                        <input type="number" class="form-control" id="campoAno" name="campoAno" placeholder="Digite o Ano de Fabrico"maxlength="4" size="4" required>
                    </div>   
                    </div>   
                    
            
  
                             <!--campo Quilometragem-->
                <div class="col-md-5">
                    <div class="form-group">
                        <label for="campoPreco">Preço</label>
                        <input type="number" class="form-control" id="campoPreco" name="campoPreco" placeholder="Digite o Preço" required>
                    </div>                                  
                </div>  
                <div class="col-md-5">
                    <div class="form-group">
                        <label for="campoTelefone">Telefone</label>
                        <input type="number" class="form-control" id="campoTelefone" name="campoTelefone" placeholder="Digite o seu Telefone" required>
                    </div>                                  
                </div>  
                <div class="col-md-5">
                    <div class="form-group">
                        <label for="campoEmail">Email</label>
                        <input type="email" class="form-control" id="campoEmail" name="campoEmail" placeholder="Digite o seu E-mail" required>
                    </div>                                  
                </div>
                             <div class="col-md-5">
    <div class="form-group">
        <img style="width: 358px; height: 200px;">
        <input type="file" class="form-control" id="arquivo" name="arquivo"   onchange="previewImagem()"  >
            </div>
            </div>
           
                            <div class="col-md-10">
                                   <div style="text-align: left">
                                       
                            <div class="col-md-2">
                            <button type="submit" class="btn btn-primary " >Submeter</button>
                        </div>
                            <div class="col-md-2">
                            <button type="reset" class="btn btn-danger" >Cancelar</button>
                        </div>
                        </div>
                        </div>
                             
               </div>
        </form>
        
            </div>
            </div>
            </div>
            </div>
        <!-- Bootstrap core JavaScript
================================================== -->
        <!-- Placed at the end of the document so the pages load faster -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
        <script src="../Boostrap4/js/bootstrap.min.js"></script>
        <script src="../Boostrap4/js/docs.min.js"></script>
        <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
        <script src="../../assets/js/ie10-viewport-bug-workaround.js"></script>
        
         <script>
        function previewImagem(){
         var imagem = document.querySelector('input[name=arquivo]').files[0];
         				var preview = document.querySelector('img');
				
				var reader = new FileReader();
				
				reader.onloadend = function () {
					preview.src = reader.result;
				}
                                if(imagem){
					reader.readAsDataURL(imagem);
				}else{
					preview.src = "";
				}
        }
        
        </script>
    </body>
</html>
