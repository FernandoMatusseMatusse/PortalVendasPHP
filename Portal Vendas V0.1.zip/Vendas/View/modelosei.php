<?php include_once("conexao.php");

	$id_categoria = $_REQUEST ['id_categoria'];
	
	$select = "SELECT * FROM sub_categoriasei WHERE categorias_id=$id_categoria ORDER BY nome";
	$result = mysqli_query($conn, $select);
	
	while ($row = mysqli_fetch_assoc($result) ) {
		$sub_categorias[] = array(
			'codigo'	=> $row['codigo'],
			'nome' => utf8_encode($row['nome']),
		);
	}
	
	echo(json_encode($sub_categorias));