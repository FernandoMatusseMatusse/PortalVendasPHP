
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.

@author Fernando Litos Cláudio Matusse
@contacto: +258846522986 / +258820308495
email: fernandomatussematusse@gmail.com
-->
<html  lang="PT-pt">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">

        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Portaldevendas.com</title>

        <!-- Bootstrap core CSS -->
        <link href="../Boostrap4/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="../Boostrap4/css/style.css" />
        
               <!-- Custom styles for this template -->
        <link href="../Boostrap4/css/dashboard.css" rel="stylesheet">
        
        
        
    </head>
    <body>
        <!--Top Menu-->
        
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="true" aria-controls="navbar">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#">Portal de Vendas</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
            <li><a >Hora</a></li>
              <li><a href="#">Nome</a></li>
            <li><a href="#">Sair</a></li>
          </ul>
          <form class="navbar-form navbar-right">
            <input type="text" class="form-control" placeholder="Busca...">
          </form>
        </div>
      </div>
    </nav>
        
        
        <!--Lateral Menu-->
            <div class="container-fluid">
      <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
    <ul id="nav" >

            <li><a href="#">Home</a></li>
            <li><a href="#">Sobre Nós</a></li>
            <li><a href="#">Novidades</a></li>
            <li><a href="#">Venda</a>

                <ul>
                    <li><a href="#">Animal</a></li>
                    <li><a href="#">Automoveis</a></li>
                    <li><a href="#">Casas/Terenos</a></li>
                    <li><a href="#">Electrodomesticos e Informatica</a></li>
                    <li><a href="#">Serviços</a></li>
                    <li><a href="#">Vestuários</a></li>
                </ul>

            </li>
            <li><a href="#">Compra</a>

                <ul>
                    <li><a href="#">Animal</a></li>
                    <li><a href="#">Automoveis</a></li>
                    <li><a href="#">Casas/Terenos</a></li>
                    <li><a href="#">Electrodomesticos e Informatica</a></li>
                    <li><a href="#">Serviços</a></li>
                    <li><a href="#">Vestuários</a></li>
                </ul>

            </li>
            
        </ul>
        </div>
          
                          <div>
                    <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
                        <div class="col-md-12">
                                   <div class="container theme-showcase" role="main">
             <div class="page-header">
                <div class="col-md-2">
                    <img src="../Controller/animals_Icon.jpg"  width="100" height="100" style="margin-bottom: 25px;" >
                </div>
                <div class="col-md-7">
                <h1>Anunciar Animais</h1>
            </div>
            </div>
        <!--Formulario-->
        <form  method="post" action="../Controller/BDAnimais.php" enctype="multipart/form-data">
            <div  class="col-md-12"  style="align-self:   center">
                
                
                             <!--campo raca do animal-->
                <div class="col-md-5">
                    <div class="form-group">
                        <label for="campoNome">Nome</label>
                        <input type="text" class="form-control" id="campoNome" name="campoNome" placeholder="digite o nome do animal" required>
                    </div>                                  
                </div>    

                <!--campo tipo de animal-->
                <div class="col-md-5">
                    <div class="form-group">
                        <label for="campoTamanho">Tamanho</label>
                        <select class="form-control" id="campoTamanho" name="campoTamanho">
                             <option >Escolha uma Opção</option>
                        <option>Muito Pequeno</option>
                        <option>Pequeno</option>
                        <option>Médio</option>
                        <option>Grande</option>
                        <option>Muito Grande</option>
                        </select>
                    </div>                                  
                </div>
                
               
               
                          

    <!-- campo idade do animal-->
                <div class="col-md-5">
                    <div class="form-group">
                        <label for="campoIdade">Idade</label>
                        <select class="form-control" id="campoIdade" name="campoIdade">
                             <option>Escolha uma opção</option>
                        <option>-1 Mes</option>
                        <option>1-3 Meses</option>
                        <option>3-6 Meses</option>
                        <option>6-9 Meses</option>
                        <option>9-12 Meses</option>
                        <option>+1 Ano</option>
                        </select>
                    </div>                                  
                </div>
    
    <!-- campo idade do animal-->
                <div class="col-md-5">
                    <div class="form-group">
                        <label for="campoTemperamento">Temperamento</label>
                        <select class="form-control" id="campoTemperamento" name="campoTemperamento">
                             <option>Escolha uma opção</option>
                        <option>Agitado</option>
                        <option>Brincalhão</option>
                        <option>Carinhoso</option>
                        <option>Dócil</option>
                        <option>Feroz</option>
                        <option>Outros Temperamentos</option>
                        </select>
                    </div>                                  
                </div>
    <!-- campo idade do animal-->
                <div class="col-md-5">
                    <div class="form-group">
                        <label for="campoSexo">Sexo</label>
                        <select class="form-control" id="campoSexo" name="campoSexo">
                             <option>Escolha uma opção</option>
                        <option>Masculino</option>
                        <option>Femenino</option>
                        </select>
                    </div>                                  
                </div>

<!--campo morada-->
    <div class="col-md-5">
        <div class="form-group">
            <label for="campoPreco">Preço</label>
            <input   type="number" class="form-control" id="campoPreco" name="campoPreco" placeholder="digite o Preço" required>       
          </div>
    </div>

<!--campo email-->
<div class="col-md-5">
    <div class="form-group">
        <label for="campoEmail" >E-mail </label>
        <input type="text" class="form-control" id="campoEmail" name="campoEmail" placeholder="digite o E-Mail" required>
            </div>
            </div>
<!--campo telefone-->
<div class="col-md-5">
    <div class="form-group">
        <label for="campoTelefone" >Telefone</label>
        <input type="number" class="form-control" id="campoTelefone" name="campoTelefone" placeholder="digite o seu Telefone" required>
            </div>
            </div>



<div class="col-md-5">
    <div class="form-group">
        <img style="width: 358px; height: 200px;">
        <input type="file"   class="form-control" id="arquivo" name="arquivo"  onchange="previewImagem()"  >
            </div>
            </div>


        
            </div>
                            <div class="col-md-10">
                                   <div style="text-align: left">
                                       
                            <div class="col-md-2">
                            <button type="submit" class="btn btn-primary " >Submeter</button>
                        </div>
                            <div class="col-md-2">
                            <button type="reset" class="btn btn-danger" >Cancelar</button>
                        </div>
                        </div>
                        </div>
        </form>

               </div>
            </div>
            </div>
            </div>
            </div>
            </div>
        <!-- Bootstrap core JavaScript
================================================== -->
        <!-- Placed at the end of the document so the pages load faster -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="../Boostrap4/js/bootstrap.min.js"></script>
        <script src="../Boostrap4/js/docs.min.js"></script>
        <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
        <script src="../../assets/js/ie10-viewport-bug-workaround.js"></script>
        
        <script>
        function previewImagem(){
         var imagem = document.querySelector('input[name=arquivo]').files[0];
         				var preview = document.querySelector('img');
				
				var reader = new FileReader();
				
				reader.onloadend = function () {
					preview.src = reader.result;
				}
                                if(imagem){
					reader.readAsDataURL(imagem);
				}else{
					preview.src = "";
				}
        }
        
        </script>
    </body>
</html>
