
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.

@author Fernando Litos Cláudio Matusse
@contacto: +258846522986 / +258820308495
email: fernandomatussematusse@gmail.com
-->
<html  lang="PT-pt">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">

        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

      <title>Portaldevendas.com</title>

        <!-- Bootstrap core CSS -->
        <link href="../Boostrap4/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="../Boostrap4/css/style.css" />
        
               <!-- Custom styles for this template -->
        <link href="../Boostrap4/css/dashboard.css" rel="stylesheet">
        
        
        
    </head>
    <body>
        <!--Top Menu-->
        
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="true" aria-controls="navbar">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
                  <a class="navbar-brand" href="#">Portal de Vendas</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
            <li><a >Hora</a></li>
              <li><a href="#">Nome</a></li>
            <li><a href="#">Sair</a></li>
          </ul>
          <form class="navbar-form navbar-right">
            <input type="text" class="form-control" placeholder="Busca...">
          </form>
        </div>
      </div>
    </nav>
        
        
        <!--Lateral Menu-->
            <div class="container-fluid">
      <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
    <ul id="nav" >

            <li><a href="#">Home</a></li>
            <li><a href="#">Sobre Nós</a></li>
            <li><a href="#">Novidades</a></li>
            <li><a href="#">Venda</a>

                <ul>
                    <li><a href="#">Animal</a></li>
                    <li><a href="#">Automoveis</a></li>
                    <li><a href="#">Casas/Terenos</a></li>
                    <li><a href="#">Electrodomesticos e Informatica</a></li>
                    <li><a href="#">Serviços</a></li>
                    <li><a href="#">Vestuários</a></li>
                </ul>

            </li>
            <li><a href="#">Compra</a>

                <ul>
    
                    <li><a href="#">Animal</a></li>
                    <li><a href="#">Automoveis</a></li>
                    <li><a href="#">Casas/Terenos</a></li>
                    <li><a href="#">Electrodomesticos e Informatica</a></li>
                    <li><a href="#">Serviços</a></li>
                    <li><a href="#">Vestuários</a></li>
                </ul>

            </li>

        </ul>
        </div>
          
                          <div>
                    <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
                        <div class="col-md-12">
                                   <div class="container theme-showcase" role="main">
             <div class="page-header">
                <div class="col-md-2">
                    <img src="../Controller/electrodomésticos-icon.jpg"  width="100" height="100" style="margin-bottom: 25px;" >
                </div>
                <div class="col-md-7">
                <h1>Anunciar Electrodomésticos</h1>
            </div>
            </div>
        <!--Formulario-->
        <form  method="post" action="../Controller/BDElectroInformatica.php" enctype="multipart/form-data">
            <div  class="col-md-12"  style="align-self:   center">
             
                      <div class="col-md-5">
                    <div class="form-group">
                        <label for="campoTipo">Tipo</label>
                        <select class="form-control" id="campoTipo" name="campoTipo">
                                                        <option>Escolha uma opção</option>
                                                        <option>Hardware</option>
                                                        <option>Software</option>
                                                        <option>Telefone</option>
                                                        <option>Electromestico</option>
                                                        <option>Outro</option>
                        </select>
                    </div>                                  
                </div>
                
                      <div class="col-md-5">
                    <div class="form-group">
                        <label for="campoMarca">Marca</label>
  <input type="text" class="form-control" id="campoMarca" name="campoMarca" placeholder="Digitea Marca" required>
                    </div>                                  
                </div>
                   
                <div class="col-md-5">
                    <div class="form-group">
                        <label for="campoModelos">Modelo</label>
                        <input type="text" class="form-control" id="campoModelos" name="campoModelos" placeholder="Digite o Modelo" required>
                    </div>                                  
                </div>  
                   
                <div class="col-md-5">
                    <div class="form-group">
                        <label for="campoDescricao">Descricao</label>
                        <textarea class="form-control" id="campoDescricao" name="campoDescricao" placeholder="Digite o Modelo" required></textarea>
                    </div>                                  
                </div>  
                   
                <div class="col-md-5">
                    <div class="form-group">
                        <label for="campoBairro">Bairro</label>
                        <input class="form-control" id="campoBairro" name="campoBairro" placeholder="Digite o Bairro" required>
                    </div>                                  
                </div>  
                             <!--campo Quilometragem-->
                <div class="col-md-5">
                    <div class="form-group">
                        <label for="campoPreco">Preço</label>
                        <input type="number" class="form-control" id="campoPreco" name="campoPreco" placeholder="Digite o Preço" required>
                    </div>                                  
                </div>  
                <div class="col-md-5">
                    <div class="form-group">
                        <label for="campoTelefone">Telefone</label>
                        <input type="number" class="form-control" id="campoTelefone" name="campoTelefone" placeholder="Digite o seu Telefone" required>
                    </div>                                  
                </div>  
                <div class="col-md-5">
                    <div class="form-group">
                        <label for="campoEmail">Email</label>
                        <input type="email" class="form-control" id="campoEmail" name="campoEmail" placeholder="Digite o seu E-mail" required>
                    </div>                                  
                </div>
                             <div class="col-md-5">
    <div class="form-group">
        <img style="width: 358px; height: 200px;">
        <input type="file" class="form-control" id="arquivo" name="arquivo"   onchange="previewImagem()"  >
            </div>
            </div>
           
                            <div class="col-md-10">
                                   <div style="text-align: left">
                                       
                            <div class="col-md-2">
                            <button type="submit" class="btn btn-primary " >Submeter</button>
                        </div>
                            <div class="col-md-2">
                            <button type="reset" class="btn btn-danger" >Cancelar</button>
                        </div>
                        </div>
                        </div>
                             
               </div>
        </form>
        
            </div>
            </div>
            </div>
            </div>
            </div>
            </div>
        <!-- Bootstrap core JavaScript
================================================== -->
        <!-- Placed at the end of the document so the pages load faster -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
        <script src="../Boostrap4/js/bootstrap.min.js"></script>
        <script src="../Boostrap4/js/docs.min.js"></script>
        <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
        <script src="../../assets/js/ie10-viewport-bug-workaround.js"></script>
        
         <script>
        function previewImagem(){
         var imagem = document.querySelector('input[name=arquivo]').files[0];
         				var preview = document.querySelector('img');
				
				var reader = new FileReader();
				
				reader.onloadend = function () {
					preview.src = reader.result;
				}
                                if(imagem){
					reader.readAsDataURL(imagem);
				}else{
					preview.src = "";
				}
        }
        
        </script>
    </body>
</html>
