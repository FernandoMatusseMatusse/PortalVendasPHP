<?php
session_start();
if(!empty($_SESSION['id'])){
	
}
?>
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.

@author Fernando Litos Cláudio Matusse
@contacto: +258846522986 / +258820308495
@email: fernandomatussematusse@gmail.com
-->
<html  lang="PT-pt">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">

        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

      <title>Portaldevendas.com</title>

        <!-- Bootstrap core CSS -->
        <link href="../Boostrap4/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="../Boostrap4/css/style.css" />
        
               <!-- Custom styles for this template -->
        <link href="../Boostrap4/css/dashboard.css" rel="stylesheet">
        
        
        
    </head>
    <body>
        <!--Top Menu-->
        
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="true" aria-controls="navbar">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
                <img src="../Controller/barras.png" style="height: 50px; width: 175px;">
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
            <li><a >Hora</a></li>
              <li><a><?PHP  echo $_SESSION['nome']; ?></a></li>
            <li><a href= "../Controller/Sair.php">Sair</a></li>
          </ul>
          <form class="navbar-form navbar-right">
            <input type="text" class="form-control" placeholder="Busca...">
          </form>
        </div>
      </div>
    </nav>
        
        
        <!--Lateral Menu-->
            <div class="container-fluid">
      <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
    <ul id="nav" >

            <li><a href="#">Home</a></li>
            <li><a href="#">Sobre Nós</a></li>
            <li><a href="#">Venda</a>

                <ul>
                    <li><a href="#">Animal</a></li>
                    <li><a href="#">Automoveis</a></li>
                    <li><a href="#">Casas/Terenos</a></li>
                    <li><a href="#">Electrodomesticos e Informatica</a></li>
                    <li><a href="#">Serviços</a></li>
                    <li><a href="#">Vestuários</a></li>
                </ul>

            </li>
            <li><a href="#">Compra</a>

                <ul>
                    <li><a href="#">Animal</a></li>
                    <li><a href="#">Automoveis</a></li>
                    <li><a href="#">Casas/Terenos</a></li>
                    <li><a href="#">Electrodomesticos e Informatica</a></li>
                    <li><a href="#">Serviços</a></li>
                    <li><a href="#">Vestuários</a></li>
                </ul>

            </li>
            


        </ul>
        </div>
          
                          <div>
                    <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
                        <div class="col-md-12">


        
               </div>
            </div>
            </div>
            </div>
            </div>
        <!-- Bootstrap core JavaScript
================================================== -->
        <!-- Placed at the end of the document so the pages load faster -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
        <script src="../Boostrap4/js/bootstrap.min.js"></script>
        <script src="../Boostrap4/js/docs.min.js"></script>
        <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
        <script src="../../assets/js/ie10-viewport-bug-workaround.js"></script>
    </body>
</html>
