
<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.

@author Fernando Litos Cláudio Matusse
@contacto: +258846522986 / +258820308495
email: fernandomatussematusse@gmail.com
-->
<?php
include_once("../Controller/Conexao.php");
$result_selecao = "SELECT * FROM casa";
$resultado_final = mysqli_query($conn, $result_selecao);
while ($linhas = mysqli_fetch_array($resultado_final)) {
    $arquivo[] = $linhas;
}

?>
<html  lang="PT-pt">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">

        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <title>Portaldevendas.com</title>

        <!-- Bootstrap core CSS -->
        <link href="../Boostrap4/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="../Boostrap4/css/style.css" />
        
               <!-- Custom styles for this template -->
        <link href="../Boostrap4/css/dashboard.css" rel="stylesheet">
        
        
        
    </head>
    <body>
        <!--Top Menu-->
        
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="true" aria-controls="navbar">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
            <img src="../Controller/barras.png" style="height: 50px; width: 175px;">
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
            <li><a >Hora</a></li>
              <li><a href="#">Nome</a></li>
            <li><a href="#">Sair</a></li>
          </ul>
          <form class="navbar-form navbar-right">
            <input type="text" class="form-control" placeholder="Busca...">
          </form>
        </div>
      </div>
    </nav>
        
        
        <!--Lateral Menu-->
            <div class="container-fluid">
      <div class="row">
        <div class="col-sm-3 col-md-2 sidebar">
    <ul id="nav" >

            <li><a href="#">Home</a></li>
            <li><a href="#">Sobre Nós</a></li>
            <li><a href="#">Novidades</a></li>
            <li><a href="#">Venda</a>

                <ul>
                    <li><a href="#">Animal</a></li>
                    <li><a href="#">Automoveis</a></li>
                    <li><a href="#">Casas/Terenos</a></li>
                    <li><a href="#">Electrodomesticos e Informatica</a></li>
                    <li><a href="#">Serviços</a></li>
                    <li><a href="#">Vestuários</a></li>
                </ul>

            </li>
            <li><a href="#">Compra</a>

                <ul>
                    <li><a href="#">Animal</a></li>
                    <li><a href="#">Automoveis</a></li>
                    <li><a href="#">Casas/Terenos</a></li>
                    <li><a href="#">Electrodomesticos e Informatica</a></li>
                    <li><a href="#">Serviços</a></li>
                    <li><a href="#">Vestuários</a></li>
                </ul>

            </li>
            
        </ul>
        </div>
          
                          <div>
                    <div class="col-sm-9 col-sm-offset-3 col-md-10 col-md-offset-2 main">
                        <div class="col-md-12">
        <div class="container theme-showcase" role="main">
            <div class="page-header">
                <h1>Casas e Terrenos</h1>
            </div>
            <div class="row">



                <?php foreach ($arquivo as $foto) { ?>
                           <div class="col-md-3">
              <div class="card mb-4 box-shadow">
                  <img src= "<?php echo "../Controller/foto/" . $foto['img'] ?>" alt="Card image cap" width="210" height="150">
                <div  style="margin-left: 55px">
                    <p class="text-center" ><a ><h3><?php echo $foto['renda']; ?></h3></a>  </p>
                  <div class="d-flex justify-content-between align-items-center">
                    <div class="btn-group">
     <p><a href="?id=<?php echo $foto['codigo']; ?>" class="btn btn-primary" role="button">Visualizar</a> </p>
                    </div>
  
                  </div>
                </div>
              </div>
            </div>
<?php } ?>
            </div>
        </div>
        </div>
        </div>
        </div>


        <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
        <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script src="../Boostrap4/js/bootstrap.min.js"></script>
    </body>
</html>