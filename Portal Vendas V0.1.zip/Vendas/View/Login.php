<?php
session_start();
?>

<!DOCTYPE html>
 <!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.

@author Fernando Litos Cláudio Matusse
@contacto: +258846522986 / +258820308495
@email: fernandomatussematusse@gmail.com
-->
<html lang="PT-pt">
<head>
	<title>portaldevendas.com</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
<link rel="icon" type="image/png" href="../Boostrap4/images/icons/favicon.ico"/>
<!--===============================================================================================-->
<link rel="stylesheet" type="text/css" href="../Boostrap4/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="../Boostrap4/css/signin.css">

<!--===============================================================================================-->

<!--===============================================================================================-->
</head>
<body>
    
            <!--Top Menu-->
        
    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="true" aria-controls="navbar">
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
               <img src="../Controller/barras.png" style="height: 50px; width: 175px;">
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav navbar-right">
            <li><a >Hora</a></li>
              <li><a href="#">Nome</a></li>
            <li><a href="#">Sair</a></li>
          </ul>
          <form class="navbar-form navbar-right">
            <input type="text" class="form-control" placeholder="Busca...">
          </form>
        </div>
      </div>
    </nav>
        
    
		<div class="container">
			<div class="form-signin" style="background: #f1f1f1;">
                            <div id="logo">
                                <img  src="../Controller/as.png" style=" height: 130px; width: 130px; margin-left: 90px;  ">
	</div>	
                            <h2 class="text-center">Área restrita</h2>
				<?php
                  
					if(isset($_SESSION['msg'])){
						echo $_SESSION['msg'];
						unset($_SESSION['msg']);
					}
					if(isset($_SESSION['msgcad'])){
						echo $_SESSION['msgcad'];
						unset($_SESSION['msgcad']);
					}
                                  
				?>
                                <form method="POST" action="../Controller/Validacao.php">
                                    <label for="campoUsuario">Usuário</label>
                                        <input type="text" name="campoUsuario"id="campoUsuario" placeholder="Digite o seu usuário" class="form-control"><br>
					
                                        <label for="campoSenha">Senha</label>
                                        <input type="password" name="campoSenha" id="campoSenha" placeholder="Digite a sua senha" class="form-control"><br>
					
					<input type="submit" name="btnLogin" value="Acessar" class="btn btn-success btn-block">
					
					<div class="row text-center" style="margin-top: 20px;"> 
						<h4>Você ainda não possui uma conta?</h4>
                                                <a href="Cadastro.php">Crie grátis</a>
					</div>
					
					
                                        
				</form>
			</div>
		</div>
    
    		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
                <script src="../Boostrap4/js/bootstrap.min.js"></script>
</body>

</html>